import os
import glob
import nibabel as nib
from scipy import ndimage
from scipy.ndimage import gaussian_filter
from skimage.filters import threshold_otsu
import numpy as np
from skimage.filters.ridges import meijering
from skimage.filters.thresholding import threshold_local
from skimage.morphology import closing, ball


def _laplacian_enhancement(image_3d, is_2d=False, ww=300, wl=150):

    if is_2d:
        kernel = np.array([[0, 1, 0],
                           [1, -4, 1],
                           [0, 1, 0]], dtype=np.float32)
    else:
        kernel = np.zeros((3, 3, 3))
        kernel[1, 1, 1] = -24.0
        kernel[[0, 2, 1, 1, 1, 1], [1, 1, 0, 2, 1, 1], [1, 1, 1, 1, 0, 2]] = 1.0



    smoothed = gaussian_filter(image_3d, sigma=0.9)


    lower = wl - ww // 2
    upper = wl + ww // 2
    clipped = np.clip(smoothed, lower, upper)
    image_norm = (clipped - lower) / (upper - lower + 1e-8)



    raw_laplacian = ndimage.convolve(image_norm, kernel, mode='nearest')


    abs_lap = np.abs(raw_laplacian)
    clip_upper = np.percentile(abs_lap, 95)
    clip_lower = np.percentile(abs_lap, 5)

    abs_lap_clipped = np.clip(abs_lap, a_min=clip_lower, a_max=clip_upper)
    abs_lap_norm = (abs_lap_clipped - abs_lap_clipped.min()) / (abs_lap_clipped.max() - abs_lap_clipped.min() + 1e-8)

    return abs_lap_norm



def generate_lpls(root_dir='Datasets'):
       for dataset in os.listdir(root_dir):
        dataset_path = os.path.join(root_dir, dataset)

        if not os.path.isdir(dataset_path):
            continue

        
        for patient in os.listdir(dataset_path):
            patient_path = os.path.join(dataset_path, patient)

            if not os.path.isdir(patient_path):
                continue

  
            main_path = os.path.join(patient_path, 'main.nii.gz')
            liver_path = os.path.join(patient_path, 'liver.nii.gz')
            output_path = os.path.join(patient_path, 'laplacian_binary.nii.gz')

      
            img_obj = nib.load(main_path)
            image = img_obj.get_fdata(dtype=np.float32)
            liver_obj = nib.load(liver_path)
            liver = liver_obj.get_fdata(dtype=np.float32)

            # image = image*liver

     
            lap_binary = _laplacian_enhancement(image)

  
            nib.save(nib.Nifti1Image(lap_binary, affine=img_obj.affine), output_path)


if __name__ == '__main__':
    root_dir = '/root/Datasets'
    generate_lpls(root_dir)
