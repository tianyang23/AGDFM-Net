import os

import nibabel as nib
import numpy as np
import torch
import torch.nn.functional as F


class SoftSkeletonize(torch.nn.Module):

    def __init__(self, num_iter=40):

        super(SoftSkeletonize, self).__init__()
        self.num_iter = num_iter

    def soft_erode(self, img):

        if len(img.shape) == 4:
            p1 = -F.max_pool2d(-img, (3, 1), (1, 1), (1, 0))
            p2 = -F.max_pool2d(-img, (1, 3), (1, 1), (0, 1))
            return torch.min(p1, p2)
        elif len(img.shape) == 5:
            p1 = -F.max_pool3d(-img, (3, 1, 1), (1, 1, 1), (1, 0, 0))
            p2 = -F.max_pool3d(-img, (1, 3, 1), (1, 1, 1), (0, 1, 0))
            p3 = -F.max_pool3d(-img, (1, 1, 3), (1, 1, 1), (0, 0, 1))
            return torch.min(torch.min(p1, p2), p3)

    def soft_dilate(self, img):

        if len(img.shape) == 4:
            return F.max_pool2d(img, (3, 3), (1, 1), (1, 1))
        elif len(img.shape) == 5:
            return F.max_pool3d(img, (3, 3, 3), (1, 1, 1), (1, 1, 1))

    def soft_open(self, img):

        return self.soft_dilate(self.soft_erode(img))

    def soft_skel(self, img):

        img1 = self.soft_open(img)
        skel = F.relu(img - img1)

        for j in range(self.num_iter):
            img = self.soft_erode(img)
            img1 = self.soft_open(img)
            delta = F.relu(img - img1)
            skel = skel + F.relu(delta - skel * delta)

        return skel

    def forward(self, img):

        return self.soft_skel(img)



def process_nifti(input_path, output_path, num_iter=40):

    nii_img = nib.load(input_path)
    data = nii_img.get_fdata().astype(np.float32)
    original_shape = data.shape


    if nib.aff2axcodes(nii_img.affine)[2] in ('S', 'I'):  
        data_transposed = data.transpose(2, 0, 1)  # (Z, X, Y)
    else:
        data_transposed = data.copy()  # 形状变为 (Z, X, Y)



    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    tensor_data = torch.from_numpy(data_transposed).unsqueeze(0).unsqueeze(0).to(device)



    skeletonizer = SoftSkeletonize(num_iter=num_iter).to(device)
    skeleton = skeletonizer(tensor_data)


  
    threshold = 0.5
    skeleton_np = (skeleton.squeeze().cpu().numpy() > threshold).astype(np.uint8)
    skeleton_np = skeleton_np.transpose(1, 2, 0)  


    nii_out = nib.Nifti1Image(skeleton_np, nii_img.affine)
    nib.save(nii_out, output_path)




def generate_skeleton(root_dir='Datasets', save_dir='pre', num_iter=25):

    for dataset in os.listdir(root_dir):
        dataset_path = os.path.join(root_dir, dataset)
        save_dataset_path = os.path.join(save_dir, dataset)
        os.makedirs(save_dataset_path, exist_ok=True)

        if not os.path.isdir(dataset_path):
            continue


        for patient in os.listdir(dataset_path):
            patient_path = os.path.join(dataset_path, patient)

            if not os.path.isdir(patient_path):
                continue

            save_patient_path = os.path.join(save_dataset_path, patient)
            os.makedirs(save_patient_path, exist_ok=True)

       
            portal_path = os.path.join(patient_path, "portal.nii.gz")
            vein_path = os.path.join(patient_path, "vein.nii.gz")

            save_portal_path = os.path.join(save_patient_path, "portal_skeleton.nii.gz")
            save_vein_path = os.path.join(save_patient_path, "vein_skeleton.nii.gz")

            # generate skeleton
            if os.path.exists(portal_path):
                process_nifti(portal_path, save_portal_path, num_iter=num_iter)
            else:
            

            if os.path.exists(vein_path):
                process_nifti(vein_path, save_vein_path, num_iter=num_iter)
            else:
             



if __name__ == '__main__':
    root_dir = '/root/Datasets'
    save_dir = '/root/Datasets'
    generate_skeleton(root_dir, save_dir, num_iter=40)
